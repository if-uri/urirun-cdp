# urirun-cdp

The **CDP (Chrome DevTools Protocol) browser-surface primitive** for urirun, extracted from
`urirun.connectors.surfaces.cdp` as a standalone, dependency-free package.

It speaks raw CDP over a WebSocket to a Chrome DevTools endpoint and exposes the small set of
primitives the reversible window-snapshot is built on: `reachable`, `navigate`, `evaluate`,
nav-history, scroll/forms round-trip. Pure stdlib — **no `urirun` dependency** — so any connector
can adopt it without pulling in the backend.

## Why it's its own package

`extraction_audit.py --preset D` reports this surface GREEN (0 OUTWARD, 0 CYCLE; stdlib only). It
is consumed by URI, swappable, and reusable across connectors — the textbook case for lifting a
*capability primitive* out of the core. The KVM connector already carries its own deployed copy
(`urirun_connector_kvm.cdp`); this is the canonical reference implementation.

## Install

```bash
pip install -e .          # editable, from this repo
```

## Back-compat

The old import path still works via a re-export shim in the urirun package:

```python
from urirun.connectors.surfaces import cdp   # → urirun_cdp.cdp (sys.modules shim)
```

So existing code and the `test_kernel_adoption` contract test (which guards the symbols the KVM
connector relies on) keep working unchanged. That contract test skips gracefully when this package
isn't installed (`pytestmark = skipif(cdp is None)`), matching how the connector packages are
tested in their own CI rather than urirun's.

## Tests

```bash
PYTHONPATH=../urirun/adapters/python python -m pytest tests/ -q
```

The surface's own tests live here (`tests/test_cdp_surface.py`); they exercise the protocol +
snapshot primitives against a fake in-memory page, no real Chrome required.

## License

Apache-2.0 — see [LICENSE](LICENSE).
